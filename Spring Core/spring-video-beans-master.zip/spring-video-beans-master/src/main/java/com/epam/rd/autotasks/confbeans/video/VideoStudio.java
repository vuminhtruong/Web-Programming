package com.epam.rd.autotasks.confbeans.video;

public interface VideoStudio {
    Video produce();
}
