package com.epam.rd.autotasks.catalogaccess.domain;

public enum Position {
    PRESIDENT,
    MANAGER,
    ANALYST,
    CLERK,
    SALESMAN
}
