package com.rd.epam.autotasks.scopes.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class JustASecondScopeConfig {


}
