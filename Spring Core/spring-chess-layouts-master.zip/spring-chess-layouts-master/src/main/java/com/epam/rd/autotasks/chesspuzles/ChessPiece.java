package com.epam.rd.autotasks.chesspuzles;

public interface ChessPiece {
    Cell getCell();
    char toChar();
}
