package com.epam.rd.autocode.domain;

public enum Position {
    PRESIDENT,
    MANAGER,
    ANALYST,
    CLERK,
    SALESMAN
}
